import java.util.Scanner;
class playerinitialiser {

    public static String playercreate(int num){
        String order;
        if(num==0)
            order="premier";
        else
            order="deuxième ('robot' si vous voulez jouer contre un robot) ou";
        Scanner scanner = new Scanner(System.in);
        System.out.print("Saisir le pseudo du "+order+" joueur :\n>> ");
        return scanner.nextLine();
    }
}
