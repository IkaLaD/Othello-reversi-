public class Lanceur {

    public static void main(String args[]) throws InterruptedException {
        //Début de partie
        OthelloMenu.main();
    }
}
