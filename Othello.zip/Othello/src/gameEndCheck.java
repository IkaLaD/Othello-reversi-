class gameEndCheck {
    public static boolean noMorePossibility(char[][] plateau, int joueur){
        for(int a = 1 ; a < 9 ; a++){
            for(int b = 1 ; b < 9 ; b++){
                if(plateau[a][b]==' ') {
                    for (int i = -1; i <= 1; i++) {
                        for (int j = -1; j <= 1; j++) {
                            int degree = 1;
                            if (plateau[a + i][b + j] != '■' && (i != 0 || j != 0)) {
                                if (joueur == 0) {
                                    while (plateau[a + (i * degree)][b + (j * degree)] == '●') {
                                        degree++;
                                    }
                                    if (plateau[a + (i * degree)][b + (j * degree)] == '○' && degree != 1) {
                                        return false;
                                    }
                                }
                                else {
                                    while (plateau[a + (i * degree)][b + (j * degree)] == '○') {
                                        degree++;
                                    }
                                    if (plateau[a + (i * degree)][b + (j * degree)] == '●' && degree != 1) {
                                        return false;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return true;
    }

    public static void whowin(char[][] plateau, String firstplayer, String secondplayer){
        int cptnoir=0;
        int cptblanc=0;

        for(int i = 1 ; i < 9 ; i++){
            for(int j = 1 ; j < 9 ; j++){
                if(plateau[i][j]=='●')
                    cptblanc++;
                else
                    cptnoir++;
            }
        }
        if(cptblanc==cptnoir)
            System.out.println("Match nul, personne n'a gagner :(");
        else if(cptblanc>cptnoir)
            System.out.println(secondplayer+" a gagné ! score : "+cptblanc+"-"+cptnoir);
        else
            System.out.println(firstplayer+" a gagné ! score : "+cptnoir+"-"+cptblanc);
        System.out.println();
    }
}
