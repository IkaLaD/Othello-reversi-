import java.util.Scanner;
class gameProcess {
    public static void whoStart() throws InterruptedException {
        Scanner scanner = new Scanner(System.in);

        //Initialisation plateau
        char[][] plateau;
        plateau = Plateau.plateauinitialiser();

        // Initialisation joueur + qui commence
        int start = (int) (Math.random() * 2);
        String j1 = playerinitialiser.playercreate(0);
        System.out.println();
        String j2 = playerinitialiser.playercreate(1);
        System.out.println();
        String[] joueur = {j1, j2};

        // Règles du jeu
        System.out.println("L'utilisation du jeu est simple :\n\n\tLe joueur qui débutera sera tiré au sort, et devra sélectionner les coordonées de son coup.\n\tExemple : '3' puis '5' (3 pour l'axe des colonnes, 5 pour l'axe des lignes).\n\tAttention : vous devrez sélectionner une coordonées sur le plateau, et qui permet de prendre en sandwich un jeton ennemi obligatoirement !\n\tPS : Si un jouer doit jouer 2 fois d'affiler, c'est que l'autre joueur n'a pas de possibilités de coup disponible.");
        System.out.println();
        System.out.println("\tAppuyez sur 'ENTREE' quand vous aurez lu et compris les règles");
        scanner.nextLine();

        if (j2.equals("robot"))
            gameRound(j1, j2, plateau);
        else{
            if (joueur[start] == joueur[0])
                gameRound(j1, j2, plateau);
            else
                gameRound(j2, j1, plateau);
        }
    }

    public static void gameRound(String firstplayer, String secondplayer, char[][] plateau) throws InterruptedException {
        String blue = "\033[0;34m";
        String reset_color = "\033[0m";
        do {
                if (!gameEndCheck.noMorePossibility(plateau, 0)) {
                    System.out.println(firstplayer + ", placez votre jeton noir.\n");
                    PieceControl.mainControl(0, plateau);
                }
                else if(!gameEndCheck.noMorePossibility(plateau, 1)){
                    System.out.println();
                    Plateau.plateauaffichage(plateau);
                    System.out.println(blue+firstplayer + ", vous n'avez pas de coup possible pour jouer !\n"+reset_color);
                    Thread.sleep(3000);
                }
                if (!gameEndCheck.noMorePossibility(plateau, 1)) {
                    if(!secondplayer.equals("robot")) {
                        System.out.println(secondplayer + ", placez votre jeton blanc.\n");
                        PieceControl.mainControl(1, plateau);
                    }
                    if(secondplayer.equals("robot")) {
                        System.out.println("Le robot place son jeton...");
                        Plateau.plateauaffichage(plateau);
                        Thread.sleep(2000);
                        BotControl.BotPossibility(plateau, 1);
                        System.out.println();
                    }
                }
                else if(!secondplayer.equals("robot") && !gameEndCheck.noMorePossibility(plateau, 1)){
                    System.out.println();
                    Plateau.plateauaffichage(plateau);
                    System.out.println(blue+secondplayer + ", vous n'avez pas de coup possible pour jouer !\n"+reset_color);
                    Thread.sleep(3000);
                }
                else if(!gameEndCheck.noMorePossibility(plateau, 1)){
                    System.out.println();
                    Plateau.plateauaffichage(plateau);
                    System.out.println(blue+"Le robot n'a pas de coup possible pour jouer !\n"+reset_color);
                    Thread.sleep(3000);
                }
        }while(!gameEndCheck.noMorePossibility(plateau, 0) || !gameEndCheck.noMorePossibility(plateau, 1));

        Plateau.plateauaffichage(plateau);
        gameEndCheck.whowin(plateau, firstplayer, secondplayer);
    }
}
