import java.util.Scanner;
public class OthelloMenu {
    public static void main() throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        int choix=0;

        while(choix!=3) {
            System.out.println("Que souhaitez vous faire ?");
            System.out.println("\t1. Lancer une nouvelle partie.");
            System.out.println("\t2. Reprendre une ancienne partie.");
            System.out.println("\t3. Quittez le jeu.");
            choix = sc.nextInt();
            while (choix < 1 || choix > 3) {
                System.out.println("Saisissez un choix de menu valide !");
                System.out.println("\t1. Lancer une nouvelle partie.");
                System.out.println("\t2. Reprendre une ancienne partie.");
                System.out.println("\t3. Quittez le jeu.");
                choix = sc.nextInt();
            }
            if(choix==1)
                gameProcess.whoStart();
            else if(choix==2)
                System.out.println("Accès Sauvegarde");
        }
    }
}
