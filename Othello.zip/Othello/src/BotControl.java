class BotControl {

    public static void BotPossibility(char[][] plateau, int joueur) {
        int[][] resulttab = new int[64][3];
        int cptpair = 0;
        int degree = 1;
        for (int a = 1; a < 9; a++) {
            for (int b = 1; b < 9; b++) {
                if (plateau[a][b] == ' ') {
                    for (int i = -1; i <= 1; i++) {
                        for (int j = -1; j <= 1; j++) {
                            if (plateau[a + i][b + j] != '■' && (i != 0 || j != 0)) {
                                if(joueur==1) {
                                    while (plateau[a + (i * degree)][b + (j * degree)] == '○') {
                                        degree++;
                                    }
                                    if (plateau[a + (i * degree)][b + (j * degree)] == '●' && degree != 1) {
                                        resulttab[cptpair][0] = degree-1;
                                        resulttab[cptpair][1] = a;
                                        resulttab[cptpair][2] = b;
                                        cptpair++;
                                    }
                                }
                                else{
                                    while (plateau[a + (i * degree)][b + (j * degree)] == '●') {
                                        degree++;
                                    }
                                    if (plateau[a + (i * degree)][b + (j * degree)] == '○' && degree != 1) {
                                        resulttab[cptpair][0] = degree-1;
                                        resulttab[cptpair][1] = a;
                                        resulttab[cptpair][2] = b;
                                        cptpair++;
                                    }
                                }
                                degree=1;
                            }
                        }
                    }
                }
            }
        }
        BotBestPlacement(plateau, resulttab, cptpair, joueur);
    }

    public static void BotBestPlacement(char[][]plateau, int[][] resulttab, int cptpair, int joueur){
        int[][] max = new int[60][3];
        int degreemax=0;
        for(int i = 0 ; i < cptpair ; i++){ // Addition des memes coup dans différentes direction
            for(int j = i+1 ; j < cptpair ; j++){
                if(resulttab[i][1]==resulttab[j][1] && resulttab[i][2]==resulttab[j][2]){
                    resulttab[i][0]+=resulttab[j][0];
                    resulttab[j][0]=0;
                    resulttab[j][1]=0;
                    resulttab[j][2]=0;
                }
            }
        }

        for(int i = 0 ; i < cptpair ; i++){ // Quel est le maximum de jeton retournable
            if(resulttab[i][0]>degreemax)
                degreemax=resulttab[i][0];
        }

        for(int i = 0 ; i < cptpair ; i++){ // Sélection de tous les coups qui ont le maximum de jeton retournable
            if(resulttab[i][0]>=degreemax){
                max[i][0]=resulttab[i][0];
                max[i][1]=resulttab[i][1];
                max[i][2]=resulttab[i][2];
                degreemax=resulttab[i][0];
            }
        }

        int choix;
        do { // On prend un des meilleurs coup au hasard (tout ces meilleurs coups retourne le meme nombre de jeton)
            choix = (int)(Math.random() * (cptpair));
        }while(max[choix][0]==0);
        PieceControl.placementJeton(plateau, max[choix][2], max[choix][1], joueur);
    }
}