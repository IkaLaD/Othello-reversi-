import java.sql.SQLOutput;
import java.util.Scanner;
class PieceControl {
    public static void mainControl(int joueur, char[][] plateau) {
        Scanner scanner = new Scanner(System.in);
        boolean validCoordonate = false;
        int x, y;

        //Tant que la coordonées n'est pas sur le plateau ou est déjà prise
        Plateau.plateauaffichage(plateau);
        System.out.println();
        System.out.print(">> ");
        y = scanner.nextInt();
        System.out.print(">> ");
        x = scanner.nextInt();
        System.out.println();
        validCoordonate = validCoordonate(plateau, y, x, joueur);
        while (!validCoordonate || !Sandwiched(plateau, y, x, joueur)){
            Plateau.plateauaffichage(plateau);
            System.out.println("\033[0;31m"+"Renseignez des coordonées valides !"+"\033[0m");
            System.out.println();
            System.out.print(">> ");
            y = scanner.nextInt();
            System.out.print(">> ");
            x = scanner.nextInt();
            System.out.println();
            validCoordonate = validCoordonate(plateau, y, x, joueur);
        }
        placementJeton(plateau, y, x, joueur);
    }
    public static boolean validCoordonate(char[][] plateau, int y, int x, int joueur) {
        if (x < 1 || x > 8 || y < 1 || y > 8) //Sur le plateau
            return false;
        if (plateau[x][y] != ' ')
            return false;
        return true;
    }

    public static boolean Sandwiched(char[][] plateau, int y, int x, int joueur){
        int degree = 1;
        for(int i = -1 ; i <= 1 ; i++){
            for(int j = -1 ; j <= 1 ; j++){
                if(plateau[x+i][y+j]!='■' && (i!=0 || j!=0)){
                    if(joueur==0) {
                        while (plateau[x+(i*degree)][y+(j*degree)] == '●') {
                            degree++;
                        }
                        if (plateau[x+(i*degree)][y+(j*degree)] == '○' && degree!=1) {
                            return true;
                        }
                        else{
                            degree=1;
                        }
                    }
                    else {
                        while (plateau[x+(i*degree)][y+(j*degree)] == '○') {
                            degree++;
                        }
                        if (plateau[x+(i*degree)][y+(j*degree)] == '●' && degree!=1) {
                            return true;
                        }
                        else{
                            degree=1;
                        }
                    }
                }
            }
        }
        return false;
    }

    public static char[][] placementJeton(char[][] plateau, int y, int x, int joueur){
        int degree = 1;
        for(int i = -1 ; i <= 1 ; i++){
            for(int j = -1 ; j <= 1 ; j++){
                if(plateau[x+i][y+j]!='■' && (i!=0 || j!=0)){
                    if(joueur==0) {
                        while (plateau[x+(i*degree)][y+(j*degree)] == '●') {
                            degree++;
                        }
                        if (plateau[x+(i*degree)][y+(j*degree)] == '○' && degree!=1) {
                            while(degree>=0){
                                plateau[x+(i*degree)][y+(j*degree)]='○';
                                degree--;
                            }
                        }
                    }
                    else {
                        while (plateau[x+(i*degree)][y+(j*degree)] == '○') {
                            degree++;
                        }
                        if (plateau[x+(i*degree)][y+(j*degree)] == '●' && degree!=1) {
                            while(degree>=0){
                                plateau[x+(i*degree)][y+(j*degree)]='●';
                                degree--;
                            }
                        }
                    }
                }
                degree=1;
            }
        }
        return plateau;
    }
}

